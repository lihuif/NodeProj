/**
 * Created by randy on 2017/6/29.
 */
module.exports = {
    mysql: {
        host: "10.60.111.83",
        port: 63700,
        user: "root",
        password: "qwerasdf",
        database: "db_zhangyi_jls_ccs_csyy",
        charset: "utf8"
    },
    mysqlPool: {
        acquireTimeout: 10000,
        waitForConnections: true,
        connectionLimit: 10,
        queueLimit: 0
    },
    mysqlPoolCluster: {
        canRetry: true,
        removeNodeErrorCount: 5,
        restoreNodeTimeout: 0,
        defaultSelector: "RR"
    },
    session: MongoStore => {
        return {
            resave: false,//添加这行，重新保存：强制会话保存即使是未修改的；
            saveUninitialized: true,//添加这行 ，强制“未初始化的”会话保存到存储
            key: "session~",//cookie name
            cookie: {
                path: '/',
                httpOnly: true,
                secure: false, // TODO: Set to true when HTTPS was used.
                maxAge: 1000 * 60 * 60 * 24 * 30

            },
            secret: "qwerasdf",
            store: new MongoStore({
                url: 'mongodb://localhost/blog',
                db: "db_session",
                port:27017
            })
        }
    }
};