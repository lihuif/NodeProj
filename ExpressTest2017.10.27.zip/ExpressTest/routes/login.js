const express = require('express');
const connection = require('../utils/mysql-connector');
const app = express();

app.get('/', function (req,  res, next) {
    let procName = "test_proc_zy_login"; //存储过程名称
    let paramsTotal = 4;  //参数个数
//    console.log(req);
    let preHandler = (paraObj) => {
        return new Promise((resolve, reject)=>{
            let array = ['',''];
            for (let i in  paraObj){
                array.push(paraObj[i]);
            }
            resolve(array);
        });
    }

    let sufHandler = (res, rows)=> {
        if (rows[0][0].output === 0){ //存在此人

            req.session.role = 1;
            req.session.doctorid = rows[1][0].doctorcode;
//          console.log(req.session);//打印session的值
            res.json({status:0});
        }
        else if (rows[0][0].output === 1){
            res.json({status:1});
        }
        else if (rows[0][0].output === 2){
            res.json({status:2});
        }
    }
    connection.doGetQuery(req, res, procName, paramsTotal, preHandler, sufHandler);
});
module.exports = app;