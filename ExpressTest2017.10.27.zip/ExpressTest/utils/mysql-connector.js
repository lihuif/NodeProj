const mysql = require('mysql');
const settings = require("./settings");
const poolCfg = require("./mysql-node-cfg");

const poolCluster = mysql.createPoolCluster();
poolCluster.add(settings.mysqlPoolCluster);
poolCluster.add('X', poolCfg.node01);
// poolCluster.add('Y', poolCfg.node02);
// poolCluster.add('Z', poolCfg.node03);
poolCluster.getConnection((err, connection) => {
    err ? console.log(err) : console.log('Server started successfully!')
});

module.exports = {
    doGetQuery: (req, res, procName, paramsTotal, preHandler, sufHandler) => {
        let paraObj = {};
        if ( req !== null){
            for(let param in req.query) {
            paraObj[param] = req.query[param];
         }
        }
        preHandler(paraObj)
            .then((paraArray) => {
                let stmt = "CALL " + procName + "(  ";
                for (let paramsCount = 0; paramsCount < paramsTotal; paramsCount++) {
                    stmt = stmt + "?, ";
                }
                stmt = stmt.substring(0, stmt.length - 2) + ")";
                poolCluster.getConnection((err, connection) => {
                    connection.query(stmt, paraArray, (err, rows, fields) => {
                        if (err) {
                            throw err;
                        }
                        sufHandler(res, rows);
                    });
                    connection.release();
                });
            });
    },
    doPostQuery: (req, res, procName, paramsTotal, preHandler, sufHandler) => {
        req.on("data", chunk => {
                let params = JSON.parse(chunk.toString());
                let paraObj = {};
                let stmt = "CALL " + procName + "(";
                for (let param in params) {
                    paraObj[param] = params[param];
                }
                for (let paramsCount = 0; paramsCount < paramsTotal; paramsCount++) {
                    stmt = stmt + "?, ";
                }
                stmt = stmt.substring(0, stmt.length - 2) + ")";
                preHandler(JSON.stringify(paraObj))
                    .then((paraArray) => {
                        poolCluster.getConnection((err, connection) => {
                            connection.query(stmt, paraArray, (err, rows, fields) => {
                                if (err) {
                                    throw err;
                                }
                                sufHandler(res, rows);
                            });
                            connection.release();
                        });
                    })
            }
        )
    }
};
