const express = require('express');
// const router = express.Router();

module.exports = (app) => {
    app.get('/', (req, res, next) => {
        res.json("root");
    });
    app.use('/login', require('./login'));
    app.use('/todaytreatment', require('./todaytreatment'))
};

// module.exports = router;