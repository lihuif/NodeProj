/**
 * Created by randy on 2017/7/12.
 */
module.exports = (req, res, next) => {
    console.info(req.url);
    console.log(req.session.role);
    next();
  /*  const  url = /^\/consultation\/confirm-reginfo+\.[A-Za-z0-9]+\.[A-Za-z0-9]+[\/=\?%\-&_~`@[\]\':+!]*([^<>\"\"])*$/;
    switch (req.session.role) {
        default:
            console.log(req.url.test(url))
            if (req.url.test(url))
            {  //拒绝游客的路由
                res.json("denied:notlogined");
            }
            else {
                next();
            }
            break;
        case 1: console.log('111');
            if (req.url == '/login/tabledata2') {//拒绝未绑定医保卡用户的路由
                res.json("denied");
            }
            else {
                next();
            }
            break;
        case 2: //放行未限制功能角色的路由
            console.log('2222');
            next();
            break;
    }
    /*
    res.header("X-Powered-By", "rails");
    if (req.url === '/login/login') {
        next();
    } else {
        if (req.session['isLogined']) {
            next();
        } else {
            res.json("Hasn't login!");
        }
    }
    */
};