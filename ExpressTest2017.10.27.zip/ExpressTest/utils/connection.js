/**
 * Created by randy on 2017/6/29.
 */

let genericPool = require("generic-pool");
let DbDriver = require("mysql");
let settings = require("./settings");

/**
 * Step 1 - Create pool using a factory object
 */

let factory = {
    create: () => {
        return new Promise((resolve, reject) => {
            let client = DbDriver.createConnection({
                host: settings.mysql.host,
                port: settings.mysql.port,
                database: settings.mysql.database,
                user: settings.mysql.user,
                password: settings.mysql.password,
                charset: settings.mysql.charset
            });
            client.connect(err => {
                if (err) {
                    console.log("SQL CONNECT ERROR: ", err);
                } else {
                    console.log("SQL CONNECT SUCCESSFUL.");
                    resolve(client);
                }
            });
        });
    },
    destroy: client => {
        return new Promise(resolve => {
            client.on("end", () => {
                resolve();
            });
            client.disconnect();
        });
    }
};

let opts = {
    max: 10, // maximum size of the pool
    min: 5 // minimum size of the pool
};

let myPool = genericPool.createPool(factory, opts);

/**
 * Step 2 - Use pool in your code to acquire/release resources
 */

// acquire connection - Promise is resolved
// once a resource becomes available

let resourcePromise = myPool.acquire();
module.exports = {
    doGetQuery:(res, procName, handler) => {
        let paraArray = [];
        let stmt = "CALL " + procName + "()";
        resourcePromise.then(client => {
            client.query(stmt, paraArray, (err, rows, fields) => {
                if (err) {
                    throw err;
                }
                handler(res, rows);
                //myPool.release(client);
            });
        })
            .catch(function(err){
                // handle error - this is generally a timeout or maxWaitingClients
                // error
                console.log();
            });
    },
    doPostQuery : (req, res, procName, handler) => {
        req.on("data",chunk => {
            let params = JSON.parse(chunk.toString());
            let paraArray = [];
            let stmt = "CALL " + procName + "(";
            for(let param in params){
                stmt = stmt + "?, ";
                paraArray.push(params[param]);
            }
            stmt = stmt.substring(0, stmt.length - 2) + ")";
            resourcePromise.then(client => {
                client.query(stmt, paraArray, (err, rows, fields) => {
                    if (err) {
                        throw err;
                    }
                    handler(res, rows);
                    //myPool.release(client);
                });
            })
                .catch(err => {
                    // handle error - this is generally a timeout or maxWaitingClients
                    // error
                });
            }
        )
    }
};

/**
 * Step 3 - Drain pool during shutdown (optional)
 */
// Only call this once in your application -- at the point you want
// to shutdown and stop using this pool.
/*
myPool.drain().then(function() {
    myPool.clear();
});
*/