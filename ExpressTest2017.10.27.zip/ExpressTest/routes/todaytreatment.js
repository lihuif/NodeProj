const express = require('express');
const connection = require('../utils/mysql-connector');
const app = express();

app.get('/treatmentall', function (req,  res, next) {//待诊疗的病人的列表
    let procName = "test_proc_doctor_Todaytreatment"; //存储过程名称，对应的表：挂号表
    let paramsTotal = 1;                              //参数个数
    let preHandler = (paraObj) => {
        return new Promise((resolve, reject)=>{
            let array = [];
            array.push(req.session.doctorid);         //传入的参数为doctor的ID
            resolve(array);
        });
    }
    let sufHandler = (res, rows)=> {
        let response = [];
        for (let x = 0; x<rows[0].length; x++){
            let temp = {};
            temp['patientname'] = [rows[0][x].patientname];  //病人的名字
            temp['patientage'] = [rows[0][x].patientage];    //病人的年龄
            temp['bussinessid'] = [rows[0][x].bussinessid];  //业务类型
            temp['regisrsource'] = [rows[0][x].regisrsource];//挂号来源
            temp['sex'] = [rows[0][x].patientsex];           //病人性别
            temp['queuestate'] = [rows[0][x].queuestate];    //就诊状态
            response.push(temp);
        }
        res.json(response);
    }
    connection.doGetQuery(req, res, procName, paramsTotal, preHandler, sufHandler);
});

app.get('/nextpatient', function (req,  res, next) {
    console.log("1111111");
    let procName = "test_proc_doctor_NextPatient"; //存储过程名称，对应的表：挂号表
    let paramsTotal = 1;                              //参数个数
    let preHandler = (paraObj) => {
        return new Promise((resolve, reject)=>{
            let array = [];
            array.push(req.session.doctorid);         //传入的参数为doctor的ID
            resolve(array);
        });
    }
    let sufHandler = (res, rows)=> {
        console.log(rows);
        let response = [];
        for (let x = 0; x<rows[0].length; x++){
            let temp = {};
            temp['status'] = [rows[0][x].output];           //返回的状态：0表示没有正在治疗的患者，也没有还未治疗的患者；1表示没有正在治疗的患者，但是有还未治疗的患者；
            // 2表示有正在治疗的患者，但没有还未治疗的患者；3表示有正在治疗的患者，也有还未治疗的患者；
            response.push(temp);
        }
        console.log("response:"+response);
        res.json(response);

    }
    connection.doGetQuery(req, res, procName, paramsTotal, preHandler, sufHandler);
});

app.get('/treatment-undone', function (req,  res, next) {//待诊疗的病人的列表
    let procName = "test_proc_doctor_inthetreatment"; //存储过程名称，对应的表：挂号表
    let paramsTotal = 1;                              //参数个数
    let preHandler = (paraObj) => {
        return new Promise((resolve, reject)=>{
            let array = [];
            array.push(req.session.doctorid);         //传入的参数为doctor的ID
            resolve(array);
        });
    }
    let sufHandler = (res, rows)=> {
        let response = [];
        for (let x = 0; x<rows[0].length; x++){
            let temp = {};
            temp['patientname'] = [rows[0][x].patientname];  //病人的名字
            temp['patientage'] = [rows[0][x].patientage];    //病人的年龄
            temp['bussinessid'] = [rows[0][x].bussinessid];  //业务类型
            temp['regisrsource'] = [rows[0][x].regisrsource];//挂号来源
            temp['sex'] = [rows[0][x].patientsex];           //病人性别
            response.push(temp);
        }
        res.json(response);
    }
    connection.doGetQuery(req, res, procName, paramsTotal, preHandler, sufHandler);
});

app.get('/treatment-underway', function (req,  res, next) { //正在接受诊疗的病人的列表
    let procName = "test_proc_doctor_undertreatment";        //存储过程名称，对应的表：挂号表
    let paramsTotal = 1;                                     //参数个数
    let preHandler = (paraObj) => {
        return new Promise((resolve, reject)=>{
            let array = [];
            array.push(req.session.doctorid);
            resolve(array);
        });
    }
    let sufHandler = (res, rows)=> {
        let response = [];
        for (let x = 0; x<rows[0].length; x++){
            let temp = {};
            temp['patientname'] = [rows[0][x].patientname];  //病人的名字
            temp['patientage'] = [rows[0][x].patientage];    //病人的年龄
            temp['bussinessid'] = [rows[0][x].bussinessid];  //业务类型
            temp['regisrsource'] = [rows[0][x].regisrsource];//挂号来源
            temp['sex'] = [rows[0][x].patientsex];           //性别
            response.push(temp);
        }
        res.json(response);
    }
    connection.doGetQuery(req, res, procName, paramsTotal, preHandler, sufHandler);
});

app.get('/treatment-done', function (req,  res, next) {//已完成诊疗的病人的列表
    let procName = "test_proc_doctor_downtreatment"; //存储过程名称，对应的表：挂号表
    let paramsTotal = 1;                              //参数个数
    let preHandler = (paraObj) => {
        return new Promise((resolve, reject)=>{
            let array = [];
            array.push(req.session.doctorid);         //传入的参数为doctor的ID
            resolve(array);
        });
    }
    let sufHandler = (res, rows)=> {
        let response = [];
        for (let x = 0; x<rows[0].length; x++){
            let temp = {};
            temp['patientname'] = [rows[0][x].patientname];  //病人的名字
            temp['patientage'] = [rows[0][x].patientage];    //病人的年龄
            temp['bussinessid'] = [rows[0][x].bussinessid];  //业务类型
            temp['regisrsource'] = [rows[0][x].regisrsource];//挂号来源
            temp['sex'] = [rows[0][x].patientsex];           //病人性别
            response.push(temp);
        }
        res.json(response);
    }
    connection.doGetQuery(req, res, procName, paramsTotal, preHandler, sufHandler);
});
module.exports = app;