"use strict";
exports.__esModule = true;
let express = require("express");
let expressWS = require("express-ws");
let wsRouter = null;
let ququerealation ={};
let WSRouter = (function () {
    function WSRouter(server) {
        this.server = null;
        this.app = null;
        this.clients = {};
        this.server = server;
        this.app = express();
        expressWS(this.app, this.server);
    }
    WSRouter.prototype.lintenClientConnect = function () {
        let me = this;
        /* this.app.ws('/', function (ws, req) {
             ws.send('Echo from Server!');
             if (!Array.isArray(me.clients['aaa'])) {
                 me.clients['aaa'] = [];
             }
             me.clients['aaa'].push(ws);
             console.log("Into ws /!");
             ws.on('message', (msg) => {
                 console.log(msg)
                 me.receiveCmd(msg);
                 me.sendCmd('123456', 'aaa');
                 console.log("receive client msg via aaa:", msg);
             });
             ws.on("close", function (msg) {
                 console.log("client is closed");
                 for (let index = 0; index < me.clients['aaa'].length; index++) {
                     if (me.clients['aaa'][index] == this) {
                         me.clients['aaa'].splice(index, 1);
                     }
                 }
             });

         });*/
        this.app.ws('/quque', function (ws, req) {
            console.log('into quque')
           // console.log(ws.toString())
            let a=ws;
           // console.log(a);
            if (!Array.isArray(ququerealation[ws])){
                console.log('1')
                ququerealation[ws]=[];
            }
            ws.on('message', (msg) => {
               // console.log(msg)
                let data =JSON.parse(msg);
                for(let x =0;x<data.length;x++){
                    let aaa={};
                    aaa['client']=ws;
                    aaa['number']=data[x].number;
                    ququerealation[ws].push(data[x].quque);
                    if (!Array.isArray(me.clients[data[x].quque]))
                    {
                        me.clients[data[x].quque] = [];
                    }
                    me.clients[data[x].quque].push(aaa);
                }
                me.receiveCmd(msg);
                console.log("receive client msg via aaa:", msg);
            });
            ws.on("close", function (msg) {
                console.log("client is closed");
                //console.log(a==ws);
                //console.log(me.clients[ququerealation[ws][0]])
                //console.log(me.clients[ququerealation[ws][1]])
                for( let x =0 ;x<ququerealation[ws].length ; x++)
                {
                    for (let index = 0; index < me.clients[ququerealation[ws][x]].length; index++) {
                        if (me.clients[ququerealation[ws][x]][index].client == this) {
                            me.clients[ququerealation[ws][x]].splice(index, 1);
                        }
                    }
                   // console.log(ququerealation[ws][1])
                }
                //console.log(ququerealation[ws])
                //console.log(me.clients[ququerealation[ws][0]])
                //console.log(me.clients[ququerealation[ws][1]])
                // delete ququerealation[ws]
                // console.log(ququerealation[ws])
                /*for (let index = 0; index < me.clients['aaa'].length; index++) {
                    if (me.clients['aaa'][index] == this) {
                        me.clients['aaa'].splice(index, 1);
                    }
                }*/
            });
        });
        this.app.ws('/qrcode', function (ws, req) {
            console.log("Into ws /qrcode!");
            if (!Array.isArray(me.clients['qrcode'])) {
                me.clients['qrcode'] = [];
            }
            me.clients['qrcode'].push(ws);
            ws.on('message', (msg) => {
                console.log("receive client msg via qrcode:", msg);
                me.receiveCmd(msg);
                me.sendCmd('http://192.168.1.123/login/qrcode/:1', 'qrcode');
            });
            ws.on("close", function (msg) {
                console.log("client is closed");
                for (let index = 0; index < me.clients['qrcode'].length; index++) {
                    if (me.clients['qrcode'][index] == this) {
                        me.clients['qrcode'].splice(index, 1);
                    }
                }
            });
        });
        this.app.ws('/order', function (ws, req) {
            console.log("Into ws /order");
            if (!Array.isArray(me.clients['order'])) {
                me.clients['order'] = [];
            }
            me.clients['order'].push(ws);
            ws.on('message', function (msg) {
                console.log("receive client msg via order:", msg);
                me.sendCmd('R', 'order');
            });
            ws.on("close", function (msg) {
                console.log("client is closed");
                for (let index = 0; index < me.clients['order'].length; index++) {
                    if (me.clients['order'][index] == this) {
                        me.clients['order'].splice(index, 1);
                    }
                }
            });
        });
    };
    WSRouter.prototype.sendCmd = function (msg, router) {
        console.log(this.clients[router].length);
        for (let cell in this.clients[router]) {
            this.clients[router][cell].send(msg);
        }
    };
    WSRouter.prototype.callquque = function (msg, router,number) {
        console.log('quque');
        console.log(this.clients[router].length);
       // console.log(this.clients['1']);
       // console.log(this.clients['2']);
        for (let cell in this.clients[router]) {
            if(this.clients[router][cell].number-number<=5)
            {
                console.log(this.clients[router][cell].number-number<=5)
                console.log('<5')
                this.clients[router][cell].client.send(msg);
            }
            if (this.clients[router][cell].number==number)
            {
                this.clients[router].splice(cell, 1);
            }
        }
        //console.log(this.clients['1'].length);
        //console.log(this.clients['2'].length);
        console.log(this.clients[router].length);
    };
    WSRouter.prototype.callchinesequque = function (msg, router,number) {
        console.log('chinese')
        console.log(this.clients[router].length)
        for (let cell in this.clients[router]) {
            if (this.clients[router][cell].number==number)
            {
                this.clients[router].splice(cell, 1);
            }
        }
        console.log(this.clients[router].length)
    };
    WSRouter.prototype.receiveCmd = function (cmd) {};
    return WSRouter;
}());

let init = (server) => {
    if (wsRouter == null && server != null) {
        wsRouter = new WSRouter(server);
    }
    return wsRouter;
}

let sendMsg = (msg, router) => {
    wsRouter.sendCmd(msg, router);
}
let callquque =(msg, router,quque)=>{
    wsRouter.callquque(msg, router,quque);
}
let callchinesequque =(msg, router,quque)=>{
    wsRouter.callchinesequque(msg, router,quque);
}
module.exports = {
    init: init,
    sendMsg: sendMsg,
    callquque:callquque,
    callchinesequque:callchinesequque
};