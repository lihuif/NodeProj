var settings = require("./settings");
module.exports = {
    node01: {
        host: '10.60.111.83',
        port: settings.mysql.port,
        database: settings.mysql.database,
        user: settings.mysql.user,
        password: "qwerasdf",
        charset: settings.mysql.charset,
        acquireTimeout: settings.mysqlPool.acquireTimeout,
        waitForConnections: settings.mysqlPool.waitForConnections,
        connectionLimit: settings.mysqlPool.connectionLimit,
        queueLimit: settings.mysqlPool.queueLimit
    }/*,
    node02: {
        host: "192.168.1.122",
        port: settings.mysql.port,
        database: settings.mysql.database,
        user: settings.mysql.user,
        password: "qwerasdf",
        charset: settings.mysql.charset,
        acquireTimeout: settings.mysqlPool.acquireTimeout,
        waitForConnections: settings.mysqlPool.waitForConnections,
        connectionLimit: settings.mysqlPool.connectionLimit,
        queueLimit: settings.mysqlPool.queueLimit
    },
    node03: {
        host: '192.168.1.105',
        port: settings.mysql.port,
        database: settings.mysql.database,
        user: settings.mysql.user,
        password: "qwerasdf",
        charset: settings.mysql.charset,
        acquireTimeout: settings.mysqlPool.acquireTimeout,
        waitForConnections: settings.mysqlPool.waitForConnections,
        connectionLimit: settings.mysqlPool.connectionLimit,
        queueLimit: settings.mysqlPool.queueLimit
    }*/
};